# weed-soil-seg > weed-soil-seg
https://universe.roboflow.com/amos-maru-s-workspace/weed-soil-seg

Provided by a Roboflow user
License: Public Domain

